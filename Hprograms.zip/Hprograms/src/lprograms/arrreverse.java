package lprograms;

public class arrreverse {
public static void main(String[] args) {
	int arr[]= {7,99,67,45,73,24};
	for(int i=arr.length-1;i>=0;i--) {
		System.out.println(arr[i]);
	}
}
}
