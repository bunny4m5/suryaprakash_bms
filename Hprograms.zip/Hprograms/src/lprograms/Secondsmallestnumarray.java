package lprograms;
public class Secondsmallestnumarray {
			public static void main(String[] args) {
				int arr[] = {17, 18, 45, 33, 10, 8,9, 17};
				int smallest = Integer.MAX_VALUE;
				int secondSmallest = Integer.MAX_VALUE;
				for (int i = 0; i < arr.length; i++) {
					if (arr[i] < smallest) { 
						secondSmallest = smallest; 
						smallest = arr[i];        
					} else if (arr[i] < secondSmallest && arr[i] != smallest) { 
						secondSmallest = arr[i];
					}
				}
				System.out.println("The smallest number in the array is: " + smallest);
				System.out.println("The second smallest number in the array is: " + secondSmallest);
		    }
		}
