package lprograms;
import java.util.Scanner;
public class Charvow {
	public static void main(String[] args) {
		Scanner sc=new Scanner(System.in);
		System.out.println("enetr the character:");
		char ch=sc.next().charAt(0);
		if(ch=='a'||ch=='A'||ch=='e'||ch=='E'||ch=='o'||ch=='i'||ch=='I'||ch=='u'||ch=='U') {
			System.out.println("The character is a vowel");
		}
		else {
			System.out.println("th character is not a vowel");
		}
	}

}
