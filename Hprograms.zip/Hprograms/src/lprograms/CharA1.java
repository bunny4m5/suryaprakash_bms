package lprograms;
import java.util.Scanner;
public class CharA1 {
	public static void main(String[] args) {
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter the character:");
		char c=sc.next().charAt(0);
		if(Character.isLetter(c)) {
			System.out.println("the character is alphabet");
		}
		else {
			System.out.println("the character is not an alphabet");
		}
	}
	
	

}
