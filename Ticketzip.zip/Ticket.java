package com;
import java.util.Scanner;
public class Ticket {
static int availableTickets=100;
public static String book(int quantity) {
		if(quantity<=0) {
			return "Ticket quantity should be positive.";
		}
		availableTickets-=quantity;
		int totalAmount=quantity*200;
		return "Succesfully booked "+quantity+" tickets,total"+"cost:"+totalAmount +" remaining tickets: "+availableTickets;
	}
public static String showAvailableTickets() {
	return "AvailableTickets:"+availableTickets;
}
public static String CancelTickets(int quantity) {
	if(quantity<=0) {
		return "cancel quantity should be positive";
	}
	else if(quantity>(100-availableTickets)) {
		return "cannot cancel more tickets than booked";
	}
	availableTickets+=quantity;
	return "Succesfully cancelled "+quantity+" tickets,RemainingTickets :"+availableTickets;
}
public static void main(String[] args) {
	Scanner sc=new Scanner(System.in);
	while(true) {
		System.out.println("Select an option");
		System.out.println("1.Book Movie Tickets");
		System.out.println("2.Cancel Tickets");
		System.out.println("3.Show Available Tickets");
		System.out.println("4.Exit");
		int option=sc.nextInt();
		switch(option) {
		case 1:
			System.out.print("Enter the number of tickets to book:");
			int quantity=sc.nextInt();
			System.out.println(book(quantity));
			break;
		case 2:
			System.out.print("Enter the number of tickets to cancel:");
			int cancelQuantity=sc.nextInt();
			System.out.println(CancelTickets(cancelQuantity));
			break;
		case 3:
			System.out.println(showAvailableTickets());
			break;
		case 4:
			System.out.println("Thank you!Exiting.....");
			break;
			default:
				System.out.println("Invslid option...");
		}
	}
}
}