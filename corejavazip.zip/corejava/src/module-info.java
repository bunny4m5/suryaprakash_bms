/**
 * 
 */
/**
 * 
 */
module corejava {
}