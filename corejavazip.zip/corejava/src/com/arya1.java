package com;

public class arya1 {
	public static void main(String[] args) {
	String[]arr=new String[7];
	arr[0]="salaar";
	arr[1]="rrr";
	arr[2]="master";
	arr[3]="saripodha sanivaaram";
	for(int i=0;i<=arr.length-1;i++) {
		System.out.println(arr[i]);
		
	}
}
}
