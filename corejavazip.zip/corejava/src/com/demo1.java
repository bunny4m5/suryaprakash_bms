package com;

public class demo1 {
	    public static void main(String[] args) {
	        String name = "12.8678.9877";
	        String[] result = name.split("\\D");
	        for(String w:result)
	        {
	        	System.out.println(w);
	        }
	     
	    }
	}
