package com;

public class assop {
	public static void main(String[]arg) {
		int a=7;
		a +=9;
		System.out.println(a);
	}

}
