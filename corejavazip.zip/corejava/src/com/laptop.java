package com;

public class laptop {
	private String name;
	private String model;
	private String rammemory;
	private String rommemory;
	private int cost;
	public laptop() {
		}
	public laptop(String name,String model,String rammemory,String rommemory,int cost) {
		this.name=name;
		this.model=model;
		this.rammemory=rammemory;
		this.rommemory=rommemory;
		this.cost=cost;
	}
	public void setname(String name) {
		this.name=name;
	}
	public String Getname() {
		return name;
		}
	public void setmodel(String model) {
		this.model=model;
		}
	public String Getmodel() {
		return model;
	}
	public void setrammemory(String rammemory) {
		this.rammemory=rammemory;
	}
	public String Getrammemory() {
		return rammemory;
	}
	public void setrommemory(String rommemory) {
		this.rommemory=rommemory;
	}
	public String Getrommemory() {
		return rommemory;
	}
	public void setcost(int cost) {
		this.cost=cost;
	}
	public int Getcost() {
		return cost;
	}
	public void display() {
		System.out.println("name of the laptop:"+Getname());
		System.out.println("name of the model:"+Getmodel());
		System.out.println("rammemory:"+Getrammemory());
		System.out.println("rommemory:"+Getrommemory());
		System.out.println("cost of the laptop:"+Getcost());
		
	}
}
