package com;
import java.util.HashMap;
public class HashmapExample {
	public static void main(String[] args) {
		HashMap<Integer,String>map=new HashMap();
		map.put(1, "ASVR");
		map.put(2, "salaar");
		map.put(3, "bahubali");
		map.put(2, "salaar");
		System.out.println(map.get(1));
		System.out.println(map.get(2));
		System.out.println(map.containsKey(3));
		System.out.println(map.containsValue("ASVR"));
		map.remove(3);
		for(Integer Key:map.keySet()) {
			System.out.println(Key+"-->"+map.get(Key));
		}
	}

}
