package com;

public class arrayindexoutofboundexception {
public static void main(String[] args) {
	int[]arr= {1,2,3,4,5,6,7};
	try {
		int res=arr[9];
		System.out.println(res);
		}
	catch(Exception e) {
		System.out.println("that array value is not present");
	}
	
	
}
}
