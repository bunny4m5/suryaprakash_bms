package com;

public class pm {
public static void main(String[]arg){
	int start=1;
	int end=100;
	int n=3;
	int count=0;
	do {
		if(n%start==0){
			count++;
		}
	start++;
}while(start<=end);
	if(count==2){
		System.out.println("prime");
	}
	else{
		System.out.println("not prime");
	}
}}