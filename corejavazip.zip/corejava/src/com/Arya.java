package com;

public class Arya {
	public static void main(String[] args) {
		int[]arr=new int[10];
		arr[0]=1;
		arr[1]=2;
		arr[2]=5;
		arr[3]=46;
		System.out.println(arr[3]);
		System.out.println("----------");
		for(int i=0;i<=arr.length-1;i++) {
			System.out.println(arr[i]);
		}
		
	}

}
