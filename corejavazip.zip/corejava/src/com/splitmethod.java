package com;

public class splitmethod
{
	public static void main(String[] args) {
		String name="95*49+9276";
		String[] pav=name.split("\\d");
		for(String paani:pav)
		{
			System.out.println(paani);
			
		}
	}
}
