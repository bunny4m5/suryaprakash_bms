package com;

public class demoreplace {
	public static void main(String[] args) {
		String  j="hello world";
		String p="welcome to aits collage";
		String s=j.replace(j, p);
		System.out.println(s);
		String l=s.replace(" ","");
		System.out.println(l);
		String[] m=s.split("\\s+");
		for(String r:m)
		{
			System.out.println(r);
		}
	}

}
