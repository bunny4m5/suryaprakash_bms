package com;
import java.util.*;

public class greter {
	public static void main(String[] args) {
		Scanner sin=new Scanner(System.in);
		System.out.println("enetr the strg");
		String p=sin.nextLine();
		System.out.println(p);
		String ch="";
		for(int i=p.length()-1;i>=0;i--)
		{
			ch+=p.charAt(i);
			
		}
		System.out.println(ch);
		if(p.equals(ch))
		{
			System.out.println("palindrom");
			
		}
		else
		{
			System.out.println("not a palindrome");
		}
		
	}

}
