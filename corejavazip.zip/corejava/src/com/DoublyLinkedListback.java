package com;
class node1{
	int data;
	node1 next;
	node1 prev;
	node1(int val){
		data=val;
		next=null;
		prev=null;
	}
}
public class DoublyLinkedListback{
	public static void Backwardtraversal(node1 tail) {
		node1 curr=tail;
		while(curr!=null) {
			System.out.println(curr.data+"");
			curr=curr.prev;
		}
	}
	public static void main(String[] args) {
		node1 head=new node1(1);
		node1 second=new node1(2);
		node1 third=new node1(3);
		head.next=second;
		second.prev=head;
		second.next=third;
		third.prev=second;
		System.out.println("Backwardtraversal:");
		Backwardtraversal(third);
	}
 {

}
}
