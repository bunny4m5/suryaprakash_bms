package com;

public interface task5 {
	void task5();

}
