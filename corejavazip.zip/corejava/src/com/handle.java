package com;
import java.io.*;
public class handle {
	public static void main(String[] args) {
		File f=new File("evadu em anukunna bomma adiripoyindi.txt");
		try {
			boolean res=f.createNewFile();
			System.out.println(res);
			System.out.println(f.getAbsolutePath());
		}
		catch(Exception e) {
			System.out.println("its not true");
		}
		try {
			FileWriter fw=new FileWriter(f);
			fw.write("war2");
			fw.flush();
			fw.close();
		}
		catch(Exception e) {
			System.out.println("cannot write");
		}
		try {
			FileReader fr= new FileReader(f);
			for(int i=0; i<=f.length()-1;i++) {
				System.out.println((char)fr.read());
			}
		}
		catch(Exception e) {
			System.out.println("cannot read");
		}
	}

}
