package com;

public class arya2 {
	public static void main(String[] args) {
		String[]arr=new String[7];
		arr[0]="salaar";
		arr[1]="rrr";
		arr[2]="master";
		arr[3]="saripodha sanivaaram";
		for(int i=arr.length-1;i>=0;i--) {
			System.out.println(arr[i]);
	}

}
}