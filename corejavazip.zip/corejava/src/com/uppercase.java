package com;

public class uppercase {
	public static void main(String[] args) {
		String s="pavanibhumireddy";
		String pav=s.toUpperCase();
	}

}
