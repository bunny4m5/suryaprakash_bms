package com;

public class stringindexoutofbound {
	public static void main(String[] args) {
		String s="war 2";
		try {
			char ss=s.charAt(3);
			System.out.println(ss);
			}
		catch(Exception e) {
			System.out.println("it is not found");
		}
	}

}
