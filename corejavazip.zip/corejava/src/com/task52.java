package com;

public class task52  implements task51{

	@Override
	public void task5() {
		System.out.println("task5");
		// TODO Auto-generated method stub
		
	}

	@Override
	public void task51() {
		System.out.println("completed");
		// TODO Auto-generated method stub
		
	}
	public static void main(String[] args) {
		task52 t52=new task52();
		t52.task5();
		t52.task51();
		
	}

}
