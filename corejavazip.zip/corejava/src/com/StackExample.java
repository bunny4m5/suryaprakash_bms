package com;
import java.util.Stack;
public class StackExample {
	public static void main(String[] args) {
		Stack<Integer>Stack=new Stack<>();
		Stack.push(10);
		Stack.push(20);
		Stack.push(30);
		System.out.println("Stack:"+Stack);
		System.out.println("Top element:"+Stack.peek());
		System.out.println("popped:"+Stack.pop());
		System.out.println("Stack after pop:"+Stack);
		System.out.println("positon of 10:"+Stack.search(10));
		System.out.println("Is Stack Empty ?"+Stack.isEmpty());
		System.out.println("size:"+Stack.size());
	}
	

}
