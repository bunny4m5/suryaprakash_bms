package com;

public class laptop1 {
	public static void main(String[] args) {
		System.out.println("laptop details");
		laptop l=new laptop();
		l.setname("Asus");
		l.setmodel("TUF15");
		l.setrammemory("5GB");
		l.setrommemory("512GB");
	    l.setcost(80000);
	    l.display();
	    System.out.println("--------------");
	    l.setname("samsung galaxy");
	    l.setmodel("book7");
	    l.setrammemory("9GB");
	    l.setcost(100000);
	    l.display();
	    System.out.println("--------------");
	    System.out.println("--------------");
	}

}
