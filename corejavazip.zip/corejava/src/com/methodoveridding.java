package com;

public class methodoveridding {
	public void whatsappversions() {
		System.out.println("version 1-----> only single ticks");
	}

}
