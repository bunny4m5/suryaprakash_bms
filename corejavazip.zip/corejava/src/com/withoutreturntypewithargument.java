package com;

public class withoutreturntypewithargument {
public static void sub(int a,int b){
	int result=a-b;
	System.out.println(result);
}
public static void main(String[] args) {
	sub(8,5);
}
}
