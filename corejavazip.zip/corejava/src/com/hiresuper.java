package com;

public class hiresuper {
	public void car() {
		System.out.println("BMW M3");
	}
	public static void main(String[] args) {
		hiresuper h= new hiresuper();
		h.car();
	}

}
