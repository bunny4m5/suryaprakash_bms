package com;

public class arithmeticexception {
	public static void main(String[] args) {
		int x=100;
		int y=0;
		try {
			System.out.println(x/y);
		}
			catch(Exception e) {
				System.out.println("it is not possible");
			}
			{
	}

}
}