package com;

public class ifelse {
	static int age=18;
	public static void main(String[]arg) {
		if(age>=18) {
			System.out.println("person is eligible for vote");
		}
		else {
			System.out.println("person is not eligible for vote");
		}
	}

}
