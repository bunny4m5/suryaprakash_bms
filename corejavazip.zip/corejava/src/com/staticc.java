package com;

public class staticc {
	 static int a=10;
	public static void main(String[] args) {
		System.out.println(a);
	}

}
