package com;

public class method {
public static void add() {
	int a=10;
	int b=20;
	int result=a+b;
	System.out.println(result);
}
public static void main(String[]arg) {
	add();
}
}
