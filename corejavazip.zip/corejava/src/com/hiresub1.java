package com;

public class hiresub1 extends hiresuper {
	public void car1() {
		System.out.println("BMW M5");
		}
	public static void main(String[] args) {
		hiresub1 hs1=new hiresub1();
		hs1.car1();
		hs1.car();
	}

}
