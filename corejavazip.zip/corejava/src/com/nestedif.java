package com;

public class nestedif {
	public static void main(String[]arg) {
 int n=45;
		if(n%3==0) {
			if(n%9==0) {
		System.out.println("number is divisible by 3 and 9");
	}
		}
}
}