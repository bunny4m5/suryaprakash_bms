package com;

public class arithop {
	public static void main(String[]arg) {
		int a=5;
		int b=2;
		int c =a+b;
		int d= a-b;
		int e=a*b;
		float f=a%b;
		float g=a/b;
		System.out.println(c);
		System.out.println(d);
		System.out.println(e);
		System.out.println(f);
		System.out.println(g);
		
	}

}
