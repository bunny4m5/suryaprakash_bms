package com;
import java.util.Scanner;
public class arya4 {
	public static void main(String[] args) {
		Scanner sc=new Scanner(System.in);
		System.out.println("chinannaa  oh sorry peddananna");
		int size=sc.nextInt();
		int arr[]=new int[size];
		for(int i=0;i<=arr.length-1;i++) {
			System.out.println("maaku recounting kaavali 8 vote lu teda vacchay:"+i);
			arr[i]=sc.nextInt();
		}
		for(int i=0;i<=arr.length-1;i++) {
			if(arr[i]%2==0) {
				System.out.println("Even elements:"+arr[i]);
			}
		}
	}
}
