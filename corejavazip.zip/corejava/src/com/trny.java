package com;

public class trny {
	public static void main(String[]arg) {
		int a=10;
		int b=20;
		String result=a>b?"yes":"no";
		System.out.println(result);
	}

}
