package com;

public class forloop {
	public static void main(String[]arg) {
		int start=1;
		int end=10;
		while(start<=end) {
			System.out.println(start);
			start++;
		}
		
	}

}
