package com;

public class flipkart_methodoverloading {
	public static void payment(int num,int cvv,int bal) {
		System.out.println("paid through debit card");
	}
	public static void payment(int num,int exp) {
		System.out.println("paid through credit card");
		}
	public static void payment(int cash) {
		System.out.println("paid through COD"); 
		}
	public static void main(String[]args){
		payment(89,678,65000);
		payment(45,2029);
		payment(250);
	}

}
