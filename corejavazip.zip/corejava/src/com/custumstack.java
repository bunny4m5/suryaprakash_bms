package com;
import java.util.*;

public class custumstack {
	String[] shop;
	int cap;
	int top;
	public custumstack (int size)
	{
		top=-1;
		cap=size;
		shop=new String[cap];
	}
	void buyadd(String value)
	{
		if(top==cap-1)
		{
			System.out.println("stack is overflow");
		}
		else
		{
			shop[++top]=value;
		}
		
	}
	void display()
	{
		if(top==-1)
		{
			System.out.println("no elements in the satck");
		}
		else
		{
			for(int i=0;i<=top;i++)
			{
				System.out.println("the elements in the stack:" +shop[i]);
			}
			
		}
		
	}
	  String remove()
	{
		if(top==-1)
		{
			System.out.println("the stack is empty");
			return null;
		}
		else
		{
			String removeelement=shop[top];
			top--;
			return removeelement;
			
		}
	}
		
	public static void main(String[] args) {
		custumstack list = new custumstack(5);
		list.buyadd("milk");
		list.buyadd("soaps");
		list.buyadd("colours");
		list.buyadd("flowers");
		list.buyadd("power");
		list.display();
		list.remove();
		System.out.println("after removing");
		list.display();
		
	}	

}
