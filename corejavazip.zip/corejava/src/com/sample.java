package com;

public class sample {
static int a=20;
public static void main(String[]arg) {
	int b=10;
	System.out.println(a);
	System.out.println(b);
}
}
