package com;

public class multisuper {
	public void car() {
		System.out.println("BMW M1");
	}
	public static void main(String[] args) {
		multisuper m=new multisuper();
		m.car();
	}

}
