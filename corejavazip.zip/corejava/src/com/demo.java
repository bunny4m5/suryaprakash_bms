package com;

public class demo {
	public static void main(String[]arg) {
		int a=20;
		int s=a;
		System.out.println(s);
	}

}
