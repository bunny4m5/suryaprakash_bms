package com;

public class ClassandObject {
static String company_name="TCS";
static String company_location="hyd";
String emp_name;
int emp_id;
int emp_salary;
public static void developer() {
	System.out.println("designation is developer");
}
public void tester() {
	System.out.println("designation is tester");
}
public static void main(String[] args) {
	System.out.println("company_name");
	System.out.println("company_location");
	ClassandObject co=new ClassandObject();
	co.emp_name="akash";
	System.out.println(co.emp_name);
	co.emp_id=678;
	System.out.println(co.emp_id);
	co.emp_salary=25000;
	System.out.println(co.emp_salary);
	developer();
	System.out.println("--------");
    ClassandObject co1=new ClassandObject();
    System.out.println(company_name);
    System.out.println(company_location);
    co1.emp_name="younus";
    System.out.println(co1.emp_name);
    co1.emp_id=234;
    System.out.println(co1.emp_id);
    co1.emp_salary=100000;
    System.out.println(co1.emp_salary);
    developer();
}
}
