package com;

public class book {
	private String  title;
	private String author;
	private int Numpages;
	private int cost;
	public book() {
		}
	public book(String title,String author,int Numpages,int cost) {
	this.title=title;
	this.author=author;
	this.Numpages=Numpages;
	this.cost=cost;
}
public void SetTitle(String title) {
	this.title=title;
	}
public String Gettitle() {
	return title;
}
public void Setauthor(String author) {
	this.author=author;
}
public String Getauthor() {
	return author;
}
public void SetNumpages(int Numpages) {
	this.Numpages=Numpages;
}
public int GetNumpages() {
	return Numpages;
	}
public void Setcost(int cost) {
	this.cost=cost;
}
public int Getcost() {
	return cost;
}
public void display() {
	System.out.println("Name of the book: "+Gettitle());
	System.out.println("author  of the book: "+Getauthor());
	System.out.println("Numpages of the book: "+GetNumpages());
	System.out.println("cost of the book: "+Getcost());
	}
public static void main(String[] args) {
	System.out.println("book details");
	book m=new book();
	m.SetTitle("avengers");
	m.Setauthor("Tonystark");
	m.SetNumpages(120);
	m.Setcost(250);
	m.display();
	System.out.println("-------------");
	m.SetTitle("avengers infinity war");
	m.SetNumpages(720);
	m.Setcost(950);
	m.display();
	System.out.println("---------------");
	System.out.println("---------------");
	System.out.println("modify the Numpages of book2");
	System.out.println("---------------");
	m.SetNumpages(820);
	m.display();
}
}