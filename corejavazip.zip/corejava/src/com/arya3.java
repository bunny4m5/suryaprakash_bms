package com;

public class arya3 {
	public static void main(String[] args) {
		int[]arr= {89,83,74,50,25,79,29};
		for(int i=0;i<=(arr.length-1)/2;i++) {
			System.out.println(arr[i]);
		}
	}

}
