package com;

public interface task51 extends task5{
	void task51();

}
