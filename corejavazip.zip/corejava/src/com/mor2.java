package com;

public class mor2 extends methodoveridding {
public void whatsappversions() {
	System.out.println("version 2---->SINGLE ticks + DOUBLE ticks");
}
public static void main(String[] args) {
	mor2 m= new mor2();
	m.whatsappversions();
	
}
}
