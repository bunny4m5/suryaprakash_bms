package com;

public class nstatic {
	int age=16;
	float weight=40;
	String height="6.0";
	String hair="fall";
	public void data() {
		System.out.println("person data");
		System.out.println("age:"+age);
		System.out.println("weight:"+weight);
		System.out.println("hair:"+hair);
		System.out.println("height:"+height);
	}
	public static void main(String[] args) {
		nstatic ns=new nstatic();
		ns.data();
		
	}
	

}
