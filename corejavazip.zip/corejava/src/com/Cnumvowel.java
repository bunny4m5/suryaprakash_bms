package com;

public class Cnumvowel {

}
