package com;

public class hiresub2 extends hiresuper {
	public void car2() {
		System.out.println("BMW M7");
	}
public static void main(String[] args) {
	hiresub2 hs2= new hiresub2();
	hs2.car();
	hs2.car2();
}
}
