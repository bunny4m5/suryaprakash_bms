package com;
import java.util.Scanner;
class palindromdemo
{
	int sum=0;
	int rev=0;
	int rem=0;
	public void find(int n)
	{
		for(int i=0;i<n;i++)
		{
			if(n>0)
			{
				rem=n%10;
				rev=rev*10+rem;
				n=n/10;
				
			}	
		}
		System.out.println(rev);
		if(rev==n)
		{
			System.out.println("yes");
		}
	}
}
public class palindrome {
	public static void main(String[] args) {
		palindromdemo pn=new palindromdemo();
		pn.find(101);
	}

}
